package alisolarflare.thebuttonrebirth;

import java.util.logging.Logger;

import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.java.JavaPlugin;

import alisolarflare.thebuttonrebirth.commands.CreateShrine;

public class MainClass extends JavaPlugin{
	public void onEnable(){
		
		//Logs Plugin Enabled onto Minecraft Log
		PluginDescriptionFile pdfFile = getDescription();
		Logger logger = getLogger();
		logger.info(pdfFile.getName() + " has been Enabled (V." + pdfFile.getVersion()+ ").");
		
		//Registers Commands and Events
		registerCommands();
		registerEvents();
		
	}
	public void onDisable(){
		
		//Logs Plugin Disabled onto Minecraft Log
		PluginDescriptionFile pdfFile = getDescription();
		Logger logger = getLogger();
		logger.info(pdfFile.getName() + " has been Enabled (V." + pdfFile.getVersion()+ ").");
		
	}
	public void registerCommands(){
		//Creates Chest
		//Creates Beacon Base
		//Creates the Button Health bar using the Boss Health Effect
		
		//Updates the Health Bar
		getCommand("createShrine").setExecutor(new CreateShrine());
	}
	public void registerEvents(){
		//Checks Chest every 24 hours
		//Makes dragon sound if button is repowered.
		//Makes wither effect if button is not repowered.
	}
}
